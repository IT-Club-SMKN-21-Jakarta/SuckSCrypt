# suckscrypt/__init__.py
from .core import generate_key, sucks_encrypt, sucks_decrypt